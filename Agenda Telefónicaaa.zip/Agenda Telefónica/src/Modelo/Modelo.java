package Modelo;

import Clases.Conexión;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


public class Modelo {
    private PreparedStatement PS;
    private DefaultTableModel DT;
    private ResultSet RS;
    private final Conexión CN;
    private final String SQL_SELECT_AGE = "SELECT *FROM persona ORDER BY per_apellidos ASC";
    private final String SQL_INSERT_AGE = "INSERT INTO persona (per_nombres, per_apellidos, per_telefono1, per_telefono2) values (?,?,?,?)";
    
    public Modelo(){
        PS = null;
        CN = new Conexión();
    }
    
    
    private DefaultTableModel setTitulosRegistroCliente(){
        DT = new DefaultTableModel();
        DT.addColumn("Apellidos");
        DT.addColumn("Nombres");
        DT.addColumn("Teléfono 1");
        DT.addColumn("Teléfono 2");
        return DT;  
    }
    
    public DefaultTableModel getDatosAgenda(){
        try {
            setTitulosRegistroCliente();
            PS = CN.getConnection().prepareStatement(SQL_SELECT_AGE);
            RS = PS.executeQuery();
            Object[] fila = new Object[4];
            while(RS.next()){
                fila[0] = RS.getString(2);
                fila[1] = RS.getString(1);
                fila[2] = RS.getString(3);
                fila[3] = RS.getString(4);
                DT.addRow(fila);
            }
        } catch (SQLException e) {
            System.err.println("Error al listar los datos."+e.getMessage());
        } finally{
            PS = null;
            RS = null;
            CN.desconectar();
        }
        return DT;
    }
    
    public int insertDatosAge(String nom, String ape, String t1, String t2){
        int res=0;
        try {
            PS = CN.getConnection().prepareStatement(SQL_INSERT_AGE);
            PS.setString(1, nom);
            PS.setString(2, ape);
            PS.setString(3, t1);
            PS.setString(4, t2);
            res = PS.executeUpdate();
            if(res > 0){
                JOptionPane.showMessageDialog(null, "Registro Guardado Correctamente.");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, " Contacto ya registrado  ");
            System.err.println("Contacto ya se escuentra en el registro de contactos  " +e.getMessage());
        } finally{
            PS = null;
            CN.desconectar();
        }
        return res;
    }
    
    
    public int elimiarC(String telf){
        String SQL = "DELETE from persona WHERE per_telefono1="+telf;
        int res=0;
        try {
            PS = CN.getConnection().prepareStatement(SQL);
            res = PS.executeUpdate();
            if(res > 0){
                JOptionPane.showMessageDialog(null, "Contacto Eliminado");
            }
        } catch (SQLException e) {
            System.err.println("Error al eliminar el dato" +e.getMessage());
        } finally{
            PS = null;
            CN.desconectar();
        }
        return res;
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
